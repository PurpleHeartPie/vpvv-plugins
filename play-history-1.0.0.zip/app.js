/**
 * app.js —— 「历史播放」插件。
 *
 * 一句话：**把主程序记下的播放记录按天列出来**。
 *
 * 数据从哪来：主程序在切歌时写 `tracks.last_played_at` / `play_count`
 * （v2.0.6 才补上写入点），插件通过 `library.history` 只读访问。
 *
 * 这个插件刻意做得很「薄」：
 *   - 不订阅 `trackChange` 自己攒记录 —— 那样只有在面板打开时才有数据，
 *     关掉就漏记，用户看到的会是一份残缺的历史；
 *   - 不写任何配置 —— 没有 `config.*` 权限需求，纯只读；
 *   - 不提供「播放」按钮 —— 沙箱不给 `player.*` 权限，点了也不会有事发生，
 *     放一个假按钮比不放更糟。
 */

import { vp } from './vp.js';

/** 一次最多取多少条（主程序上限 500）。 */
const LIMIT = 300;

/** `library.history` 返回的原始列表。 */
let tracks = [];
let loading = false;

const $ = (id) => document.getElementById(id);
const listEl = $('list');
const emptyEl = $('empty');
const summaryEl = $('summary');
const footEl = $('foot');
const refreshBtn = $('refresh');

/* ------------------------------------------------------------------ *
 * 时间处理
 * ------------------------------------------------------------------ */

/**
 * 把 ISO 时间串转成「今天 / 昨天 / N 天前」的分组标签。
 *
 * 后端存的是 UTC（`utc_now_iso()`），而用户关心的是本地时间的「哪一天」。
 * 所以先转成 Date，再用**本地**年月日拼 key —— 直接截字符串会把「昨晚 23:30」
 * 算成「今天」（时区差 8 小时）。
 *
 * @param {string} iso ISO 时间串
 * @returns {{key: string, label: string}}
 */
function groupOf(iso) {
  const when = new Date(iso);
  if (Number.isNaN(when.getTime())) return { key: 'unknown', label: '时间未知' };

  const today = new Date();
  const dayOf = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diffDays = Math.round((dayOf(today) - dayOf(when)) / 86400000);

  if (diffDays <= 0) return { key: 'd0', label: '今天' };
  if (diffDays === 1) return { key: 'd1', label: '昨天' };
  if (diffDays < 7) return { key: `d${diffDays}`, label: `${diffDays} 天前` };
  return {
    key: `m${when.getFullYear()}-${when.getMonth()}`,
    label: `${when.getMonth() + 1} 月 ${when.getDate()} 日`,
  };
}

/**
 * 相对时间（列表每行右侧那个）。
 * @param {string} iso ISO 时间串
 * @returns {string}
 */
function relativeTime(iso) {
  const when = new Date(iso);
  if (Number.isNaN(when.getTime())) return '';
  const diffMin = Math.round((Date.now() - when.getTime()) / 60000);
  if (diffMin < 1) return '刚刚';
  if (diffMin < 60) return `${diffMin} 分钟前`;
  const hour = when.getHours();
  const minute = String(when.getMinutes()).padStart(2, '0');
  const diffHour = Math.round(diffMin / 60);
  if (diffHour < 6) return `${diffHour} 小时前`;
  return `${String(hour).padStart(2, '0')}:${minute}`;
}

/**
 * 秒数 → `m:ss`。
 * @param {number} sec 秒
 * @returns {string}
 */
function formatDuration(sec) {
  if (!Number.isFinite(sec) || sec <= 0) return '';
  const m = Math.floor(sec / 60);
  const s = String(Math.round(sec % 60)).padStart(2, '0');
  return `${m}:${s}`;
}

/* ------------------------------------------------------------------ *
 * 渲染
 * ------------------------------------------------------------------ */

/**
 * 建一个元素（不引第三方库，十几行就够）。
 * @param {string} tag `div.a.b` 这种写法
 * @param {object} [attrs]
 * @param {(Node|string)[]} [children]
 * @returns {HTMLElement}
 */
function el(tag, attrs = {}, children = []) {
  const [name, ...classes] = tag.split('.');
  const node = document.createElement(name || 'div');
  if (classes.length) node.className = classes.join(' ');
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (key === 'text') node.textContent = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === undefined) continue;
    node.append(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return node;
}

/**
 * 一行曲目。
 * @param {object} track `library.history` 里的一项
 * @returns {HTMLElement}
 */
function renderRow(track) {
  const meta = [track.artistName, track.albumName].filter(Boolean).join(' · ');
  const duration = formatDuration(track.durationSec);
  const plays = Number(track.playCount) || 0;

  return el('div.row', {}, [
    el('div.row__main', {}, [
      el('div.row__title', { title: track.title || '' }, [track.title || '未知曲目']),
      el('div.row__meta', {}, [meta || '—']),
    ]),
    el('div.row__side', {}, [
      // 播放次数只在 >1 时显示：绝大多数曲目只听一次，全显示会很吵
      plays > 1 ? el('span.row__plays', { title: `共播放 ${plays} 次` }, [`×${plays}`]) : null,
      duration ? el('span.row__dur', {}, [duration]) : null,
      el('span.row__when', { title: track.lastPlayedAt }, [relativeTime(track.lastPlayedAt)]),
    ]),
  ]);
}

/**
 * 把 `tracks` 渲染成「按天分组」的列表。
 * @returns {void}
 */
function render() {
  listEl.textContent = '';

  if (!tracks.length) {
    summaryEl.hidden = true;
    emptyEl.hidden = false;
    emptyEl.textContent = '还没有播放记录 —— 在主界面播放几首之后回来看看。';
    footEl.hidden = false;
    return;
  }

  emptyEl.hidden = true;
  summaryEl.hidden = false;

  const todayKey = groupOf(new Date().toISOString()).key;
  const todayCount = tracks.filter((t) => groupOf(t.lastPlayedAt).key === todayKey).length;
  $('stat-total').textContent = String(tracks.length);
  $('stat-today').textContent = String(todayCount);
  $('stat-last').textContent = relativeTime(tracks[0].lastPlayedAt) || '—';

  // 后端已经按时间倒序，这里只需顺序扫、遇到新分组就插一个标题
  let currentKey = '';
  for (const track of tracks) {
    const group = groupOf(track.lastPlayedAt);
    if (group.key !== currentKey) {
      currentKey = group.key;
      listEl.append(el('div.group', { text: group.label }));
    }
    listEl.append(renderRow(track));
  }

  footEl.hidden = false;
}

/**
 * 拉一次历史。
 * @returns {Promise<void>}
 */
async function load() {
  if (loading) return;
  loading = true;
  refreshBtn.disabled = true;
  refreshBtn.classList.add('is-busy');
  try {
    const result = await vp.call('library.history', { limit: LIMIT });
    const items = result && Array.isArray(result.tracks) ? result.tracks : [];
    // `lastPlayedAt` 为空的记录排不到有意义的位置，直接丢掉
    tracks = items.filter((t) => t && t.lastPlayedAt);
    render();
  } catch (err) {
    tracks = [];
    summaryEl.hidden = true;
    emptyEl.hidden = false;
    emptyEl.textContent = `读取失败：${(err && err.message) || '未知错误'}`;
  } finally {
    loading = false;
    refreshBtn.disabled = false;
    refreshBtn.classList.remove('is-busy');
  }
}

/* ------------------------------------------------------------------ *
 * 启动
 * ------------------------------------------------------------------ */

refreshBtn.addEventListener('click', () => {
  load();
});

// 面板打开时先拉一次
load();

// 宿主推 `trackChange` 时不必立刻重拉（会打断阅读），但也别让列表一直旧着 ——
// 只做一件事：把「最近一次」「今天」两个数字更新掉。列表本身等用户点刷新。
vp.on('trackChange', () => {
  // 静默地在后台重拉一次，不阻塞界面
  load();
});
