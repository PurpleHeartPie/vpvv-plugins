/**
 * vp.js —— 插件侧的 postMessage 客户端（**参考实现，抄这十几行就够**）。
 *
 * vpvvMusic 的插件运行在一个独立端口的 iframe 里，和主界面之间只靠 postMessage
 * 说话。协议很小，但有三条硬约束：
 *
 *  1. **每条消息都必须带 `vp: 1`**（数字，不是字符串 '1'）。宿主拿它当门票，
 *     不带的包会被直接丢弃 —— 这样插件页面里的第三方脚本也没法乱调 API。
 *  2. **`params` / `result` 必须是普通可序列化对象**：不能是函数、DOM 节点、
 *     class 实例。结构化克隆传不过去，宿主也不会替你转换。
 *  3. **不要自己去猜宿主的 origin**：用 `window.parent` 发即可。宿主侧会校验
 *     `event.source` 与 `event.origin`，方向反了（比如往 `window.top` 发）就收不到。
 *
 * 消息形状：
 *
 *   插件 → 宿主
 *     { vp: 1, type: 'ready' }
 *     { vp: 1, type: 'request', id: <number>, method: <string>, params?: <object> }
 *
 *   宿主 → 插件
 *     { vp: 1, type: 'response', id: <number>, result?: any }
 *     { vp: 1, type: 'response', id: <number>, error: { code: <string>, message: <string> } }
 *     { vp: 1, type: 'event', event: <string>, data: any }
 *
 * 可用的 method 由宿主的白名单决定，不认识的会回 `E_UNKNOWN_METHOD`；
 * manifest 里没声明对应权限的会回 `E_PERMISSION`。连续失败多次插件会被自动停用。
 */

const VERSION = 1;

/** 已经发出去、还没等到回包的请求：id -> {resolve, reject}。 */
const pending = new Map();
/** 事件订阅：event -> 回调数组。 */
const handlers = new Map();
/** 请求 id 自增。 */
let nextId = 1;

window.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || typeof msg !== 'object' || msg.vp !== VERSION) return;

  if (msg.type === 'response') {
    const waiting = pending.get(msg.id);
    if (!waiting) return;
    pending.delete(msg.id);
    if (msg.error) waiting.reject(new Error(msg.error.message || msg.error.code || '插件请求失败'));
    else waiting.resolve(msg.result);
    return;
  }

  if (msg.type === 'event') {
    for (const fn of handlers.get(msg.event) || []) {
      try {
        fn(msg.data);
      } catch (err) {
        console.error('[vp] 事件处理异常', msg.event, err);
      }
    }
  }
});

/**
 * 向宿主报到。打开插件时先调一次，让宿主知道页面已经起来了。
 * @returns {void}
 */
export function ready() {
  window.parent.postMessage({ vp: VERSION, type: 'ready' }, '*');
}

/**
 * 调一个宿主方法。
 * @param {string} method 方法名（见宿主白名单，如 'player.state'）
 * @param {object} [params] 参数（必须是普通可序列化对象）
 * @returns {Promise<any>} 成功时的 result；失败时 reject 一个带 message 的 Error
 */
export function call(method, params) {
  const id = nextId;
  nextId += 1;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    window.parent.postMessage({ vp: VERSION, type: 'request', id, method, params }, '*');
  });
}

/**
 * 订阅宿主事件（`trackChange` / `playingChange`）。
 * @param {string} event 事件名
 * @param {(data:any) => void} fn 回调
 * @returns {() => void} 取消订阅
 */
export function on(event, fn) {
  if (!handlers.has(event)) handlers.set(event, []);
  handlers.get(event).push(fn);
  return () => {
    const list = handlers.get(event) || [];
    const index = list.indexOf(fn);
    if (index >= 0) list.splice(index, 1);
  };
}

export const vp = { ready, call, on };

export default vp;
