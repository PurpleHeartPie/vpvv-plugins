/**
 * app.js —— 「收听统计」示例插件的逻辑。
 *
 * 这个插件的存在意义只有一个：**证明插件 API 真的能通**。所以它只做四件事：
 *
 *  1. `vp.ready()` 之后读自己的配置（`config.get`），拿到历史统计；
 *  2. 订阅 `trackChange`，每换一首就往历史里记一笔（次数 / 时长 / 当天）；
 *  3. 画最近 7 天的柱状图（纯 div + 高度百分比，不引任何外部库）；
 *  4. 「保存」按钮把统计写回自己的配置（`config.set`），关闭窗口时也尽力存一次。
 *
 * 它**不**做的事：不改曲库、不写文件、不联网、不碰播放器控制。
 */

import { vp } from './vp.js';

/** 图表显示几天。 */
const DAYS = 7;

/** 当前统计（内存里的一份，保存时整体写回）。 */
let stats = { days: {}, totalSec: 0, plays: 0 };
/** 自上次保存以来有没有新的记录。 */
let dirty = false;
/** 本次会话（从打开到关闭）记录到的曲目数。 */
let sessionPlays = 0;

const nodes = {
  now: document.getElementById('now'),
  plays: document.getElementById('card-plays'),
  hours: document.getElementById('card-hours'),
  today: document.getElementById('card-today'),
  bars: document.getElementById('bars'),
  chartMeta: document.getElementById('chart-meta'),
  save: document.getElementById('save'),
  hint: document.getElementById('hint'),
};

/**
 * 本地日期键（`YYYY-MM-DD`）。
 * @param {Date} date
 * @returns {string}
 */
function dayKey(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * 最近 `count` 天的键（从早到晚）。
 * @param {number} count
 * @returns {string[]}
 */
function recentDays(count) {
  const out = [];
  const today = new Date();
  for (let i = count - 1; i >= 0; i -= 1) {
    const day = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i);
    out.push(dayKey(day));
  }
  return out;
}

/**
 * 把配置里的任意形状收敛成合法统计（配置可能被手改坏）。
 * @param {*} raw
 * @returns {{days: Object<string, number>, totalSec: number, plays: number}}
 */
function normalizeStats(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const days = {};
  const rawDays = source.days && typeof source.days === 'object' ? source.days : {};
  for (const [key, value] of Object.entries(rawDays)) {
    const count = Number(value);
    if (/^\d{4}-\d{2}-\d{2}$/.test(key) && Number.isFinite(count) && count > 0) {
      days[key] = Math.trunc(count);
    }
  }
  const totalSec = Number(source.totalSec);
  const plays = Number(source.plays);
  return {
    days,
    totalSec: Number.isFinite(totalSec) && totalSec > 0 ? Math.trunc(totalSec) : 0,
    plays: Number.isFinite(plays) && plays > 0 ? Math.trunc(plays) : 0,
  };
}

/** 刷新三个数字卡片。 */
function renderCards() {
  const today = stats.days[dayKey(new Date())] || 0;
  nodes.plays.textContent = String(stats.plays);
  nodes.hours.textContent = (stats.totalSec / 3600).toFixed(1);
  nodes.today.textContent = String(today);
}

/** 画最近 7 天柱状图（纯 div，高度按当天最大值归一化成百分比）。 */
function renderBars() {
  const days = recentDays(DAYS);
  const counts = days.map((key) => stats.days[key] || 0);
  const max = Math.max(1, ...counts);
  const total = counts.reduce((sum, value) => sum + value, 0);

  nodes.bars.replaceChildren();
  days.forEach((key, index) => {
    const count = counts[index];
    // 有记录的最小给 6%，否则「1 首」会看成一格空白。
    const height = count > 0 ? Math.max(6, Math.round((count / max) * 100)) : 0;
    const column = document.createElement('div');
    column.className = 'bar';

    const bar = document.createElement('div');
    bar.className = 'bar__fill';
    bar.style.height = `${height}%`;

    const value = document.createElement('span');
    value.className = 'bar__value';
    value.textContent = count > 0 ? String(count) : '';

    const label = document.createElement('span');
    label.className = 'bar__label';
    label.textContent = key.slice(5);

    column.append(value, bar, label);
    nodes.bars.append(column);
  });

  nodes.chartMeta.textContent = total > 0 ? `共 ${total} 首` : '还没有记录';
}

/**
 * 更新「当前：歌名 - 歌手」这一行。
 * @param {object|null} track 宿主给的曲目对象
 */
function renderNow(track) {
  if (!track) {
    nodes.now.textContent = '当前：未在播放';
    return;
  }
  const title = String(track.title || '未知曲目');
  const artist = String(track.artistName || '');
  nodes.now.textContent = artist ? `当前：${title} - ${artist}` : `当前：${title}`;
}

/** 全量重画。 */
function renderAll() {
  renderCards();
  renderBars();
}

/**
 * 把统计写回插件自己的配置。
 * @param {boolean} silent 自动保存时不打扰用户
 * @returns {Promise<void>}
 */
async function save(silent) {
  try {
    const result = await vp.call('config.set', { config: stats });
    dirty = false;
    if (!silent) {
      const bytes = Number(result && result.bytes) || 0;
      nodes.hint.textContent = `已保存（${bytes} 字节，存在本机）`;
    }
  } catch (err) {
    if (!silent) nodes.hint.textContent = `保存失败：${err.message}`;
  }
}

/** 启动。 */
async function boot() {
  vp.ready();

  // 1) 当前播放（player.read）。
  try {
    const state = await vp.call('player.state');
    renderNow(state && state.track);
  } catch (_) {
    nodes.now.textContent = '当前：读取播放状态失败';
  }

  // 2) 读自己的历史（config.get）。
  try {
    const data = await vp.call('config.get');
    stats = normalizeStats(data && data.config);
  } catch (_) {
    stats = { days: {}, totalSec: 0, plays: 0 };
  }
  renderAll();

  // 3) 订阅换曲 / 播放状态（player.read）。
  vp.on('trackChange', (data) => {
    const track = data && data.track;
    if (!track) return;
    const key = dayKey(new Date());
    stats.plays += 1;
    stats.totalSec += Math.max(0, Number(track.durationSec) || 0);
    stats.days[key] = (stats.days[key] || 0) + 1;
    dirty = true;
    sessionPlays += 1;
    renderNow(track);
    renderAll();
  });
  vp.on('playingChange', (data) => {
    document.body.classList.toggle('is-playing', Boolean(data && data.playing));
    if (sessionPlays > 0 && !dirty) renderCards();
  });

  // 4) 借曲库证明 library.read 也通（只读，不改任何东西）。
  try {
    const data = await vp.call('library.artists');
    const artists = Array.isArray(data && data.artists) ? data.artists : [];
    if (artists.length) {
      nodes.chartMeta.textContent = `${nodes.chartMeta.textContent} · 曲库 ${artists.length} 位艺人`;
    }
  } catch (_) {
    /* 曲库为空或没权限都不影响统计本身 */
  }
}

nodes.save.addEventListener('click', () => {
  save(false);
});

// iframe 被宿主关掉时可能来不及走完一次异步保存，所以「保存」按钮才是主路径，
// 这里只是尽力而为。
window.addEventListener('beforeunload', () => {
  if (dirty) vp.call('config.set', { config: stats });
});

boot().catch((err) => {
  nodes.now.textContent = `初始化失败：${err.message}`;
});
